<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace RadiusTheme\Radius_Directory_Core;

use RadiusTheme\RadiusDirectory\Helper;
use \RT_Postmeta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'RT_Postmeta' ) ) {
	return;
}

$Postmeta = RT_Postmeta::getInstance();

$prefix = RADIUS_DIRECTORY_CORE_THEME_PREFIX;

/*-------------------------------------
#. Layout Settings
---------------------------------------*/
$nav_menus = wp_get_nav_menus( [ 'fields' => 'id=>name' ] );
$nav_menus = [ 'default' => esc_html__( 'Default', 'radius-directory-core' ) ] + $nav_menus;
$sidebars  = [ 'default' => esc_html__( 'Default', 'radius-directory-core' ) ] + Helper::custom_sidebar_fields();

$Postmeta->add_meta_box( "{$prefix}_page_settings", esc_html__( 'Layout Settings', 'radius-directory-core' ), [
	'page',
	'post'
], '', '', 'high', [
	'fields' => [
		"{$prefix}_layout_settings" => [
			'label' => esc_html__( 'Layouts', 'radius-directory-core' ),
			'type'  => 'group',
			'value' => [
				'layout'        => [
					'label'   => esc_html__( 'Layout', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => [
						'default'       => esc_html__( 'Default', 'radius-directory-core' ),
						'full-width'    => esc_html__( 'Full Width', 'radius-directory-core' ),
						'left-sidebar'  => esc_html__( 'Left Sidebar', 'radius-directory-core' ),
						'right-sidebar' => esc_html__( 'Right Sidebar', 'radius-directory-core' ),
					],
					'default' => 'default',
				],
				'sidebar'       => [
					'label'   => esc_html__( 'Custom Sidebar', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => $sidebars,
					'default' => 'default',
				],
				'tr_header'     => [
					'label'   => esc_html__( 'Transparent Header', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => [
						'default' => esc_html__( 'Default', 'radius-directory-core' ),
						'on'      => esc_html__( 'Enable', 'radius-directory-core' ),
						'off'     => esc_html__( 'Disable', 'radius-directory-core' ),
					],
					'default' => 'default',
				],
				'top_bar'       => [
					'label'   => esc_html__( 'Top Bar', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => [
						'default' => esc_html__( 'Default', 'radius-directory-core' ),
						'on'      => esc_html__( 'Enable', 'radius-directory-core' ),
						'off'     => esc_html__( 'Disable', 'radius-directory-core' ),
					],
					'default' => 'default',
				],
				'header_style'  => [
					'label'   => esc_html__( 'Header Layout', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => Helper::get_header_list(),
					'default' => 'default',
				],
				'footer_style'  => [
					'label'   => esc_html__( 'Footer Style', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => Helper::get_footer_list(),
					'default' => 'default',
				],
				'banner'        => [
					'label'   => esc_html__( 'Banner', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => [
						'default' => esc_html__( 'Default', 'radius-directory-core' ),
						'on'      => esc_html__( 'Enable', 'radius-directory-core' ),
						'off'     => esc_html__( 'Disable', 'radius-directory-core' ),
					],
					'default' => 'default',
				],
				'breadcrumb'    => [
					'label'   => esc_html__( 'Breadcrumb', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => [
						'default' => esc_html__( 'Default', 'radius-directory-core' ),
						'on'      => esc_html__( 'Enable', 'radius-directory-core' ),
						'off'     => esc_html__( 'Disable', 'radius-directory-core' ),
					],
					'default' => 'default',
				],
				'banner_search' => [
					'label'   => esc_html__( 'Banner Search', 'radius-directory-core' ),
					'type'    => 'select',
					'options' => [
						'default' => esc_html__( 'Default', 'radius-directory-core' ),
						'on'      => esc_html__( 'Enabled', 'radius-directory-core' ),
						'off'     => esc_html__( 'Disabled', 'radius-directory-core' ),
					],
					'default' => 'default',
				],
				'bgimg'         => [
					'label' => esc_html__( 'Banner Search Background Image', 'radius-directory-core' ),
					'type'  => 'image',
					'desc'  => esc_html__( 'If not selected, default will be used', 'radius-directory-core' ),
				],
			]
		]
	]
] );