<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace RadiusTheme\Radius_Directory_Core;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Post extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ) {
		$this->rt_name = __( 'Post', 'radius-directory-core' );
		$this->rt_base = 'rt-post';
		parent::__construct( $data, $args );
	}

	public function rt_fields() {
		$categories        = get_categories();
		$category_dropdown = [ '0' => __( 'All Categories', 'radius-directory-core' ) ];

		foreach ( $categories as $category ) {
			$category_dropdown[ $category->term_id ] = $category->name;
		}

		$fields = [
			[
				'mode'  => 'section_start',
				'id'    => 'sec_general',
				'label' => __( 'General', 'radius-directory-core' ),
			],
			[
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'cat',
				'label'   => __( 'Categories', 'radius-directory-core' ),
				'options' => $category_dropdown,
				'default' => '0',
			],
			[
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'orderby',
				'label'   => __( 'Order By', 'radius-directory-core' ),
				'options' => [
					'date'  => __( 'Date (Recents comes first)', 'radius-directory-core' ),
					'title' => __( 'Title', 'radius-directory-core' ),
				],
				'default' => 'date',
			],
			[
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'author',
				'label'       => __( 'Author Display', 'radius-directory-core' ),
				'label_on'    => __( 'On', 'radius-directory-core' ),
				'label_off'   => __( 'Off', 'radius-directory-core' ),
				'default'     => 'yes',
				'description' => __( 'Show or hide author name', 'radius-directory-core' ),
			],
			[
				'mode' => 'section_end',
			],

			// Style Tab
			[
				'mode'  => 'section_start',
				'id'    => 'sec_style_color',
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Color', 'radius-directory-core' ),
			],
			[
				'type'      => Controls_Manager::COLOR,
				'id'        => 'bgcolor',
				'label'     => __( 'Background', 'radius-directory-core' ),
				'selectors' => [ '{{WRAPPER}} .rtin-each' => 'background-color: {{VALUE}}' ],
			],
			[
				'type'      => Controls_Manager::COLOR,
				'id'        => 'title_color',
				'label'     => __( 'Title', 'radius-directory-core' ),
				'selectors' => [ '{{WRAPPER}} .post-title a' => 'color: {{VALUE}}' ],
			],
			[
				'type'      => Controls_Manager::COLOR,
				'id'        => 'meta_color',
				'label'     => __( 'Meta', 'radius-directory-core' ),
				'selectors' => [ '{{WRAPPER}} .post-meta li, {{WRAPPER}} .post-meta li a, {{WRAPPER}} .post-date' => 'color: {{VALUE}}' ],
			],
			[
				'type'      => Controls_Manager::COLOR,
				'id'        => 'author_color',
				'label'     => __( 'Author', 'radius-directory-core' ),
				'selectors' => [ '{{WRAPPER}} .post-meta .author-name a' => 'color: {{VALUE}}' ],
				'condition' => [ 'style' => [ '1' ] ],
			],
			[
				'mode' => 'section_end',
			],
			[
				'mode'  => 'section_start',
				'id'    => 'sec_style_type',
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Typography', 'radius-directory-core' ),
			],
			[
				'mode'     => 'group',
				'type'     => \Elementor\Group_Control_Typography::get_type(),
				'id'       => 'title_typo',
				'label'    => __( 'Title', 'radius-directory-core' ),
				'selector' => '{{WRAPPER}} .post-title',
			],
			[
				'mode'     => 'group',
				'type'     => \Elementor\Group_Control_Typography::get_type(),
				'id'       => 'meta_typo',
				'label'    => __( 'Meta', 'radius-directory-core' ),
				'selector' => '{{WRAPPER}} .post-meta li, {{WRAPPER}} .post-meta li a, {{WRAPPER}} .post-date',
			],
			[
				'mode'      => 'group',
				'type'      => \Elementor\Group_Control_Typography::get_type(),
				'id'        => 'author_typo',
				'label'     => __( 'Author', 'radius-directory-core' ),
				'selector'  => '{{WRAPPER}} .post-meta .author-name a',
				'condition' => [ 'style' => [ '1' ] ],
			],
			[
				'mode' => 'section_end',
			],
		];

		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		$template = 'view-1';

		return $this->rt_template( $template, $data );
	}
}